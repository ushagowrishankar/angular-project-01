var Capstone = angular.module("Capstone", ["ngResource", "ui.router" ], function($httpProvider){});
Capstone.controller("listCtrl", function($scope, $http, listService, $timeout, $location){
	
	listService.async().then(function(d) {
      $scope.bookList = d.data;
     });
	 $scope.addBook = function(){
		 $location.path('create');
	 };
	$scope.removeBook = function(){
		 $location.path('/home');
	 };
});
Capstone.controller("editCtrl", function($scope, $http, listService, $timeout, resourceFactory ,$stateParams){
	
	$scope.thisBook = {
		"name": $scope.newBook.name,
		"description": $scope.newBook.description,
		"price": $scope.newBook.price,
		"category": $scope.newBook.category
	};
	$scope.updateBook = function(){
		resourceFactory.update({id:$stateParams.id}, $scope.thisBook, function(r){
				$scope.response = r.code;
				if( $scope.response == 200){
					$scope.modifiedFlag = true;
					
				}else {
					$scope.modifiedFlag = false;
					
				}
				console.log($scope.modifiedFlag);
			});
	}
	$scope.init= function(){
		$scope.pageTitle= "Update Book";
			$scope.editId=$stateParams.id;
			if($stateParams.id !== undefined){
				resourceFactory.get({id:$stateParams.id}, function(getBookResponse) {					
					$scope.newBook	=	getBookResponse.data;
				 });	
				}
		
	};
	
});
Capstone.controller('addNewCtrl', function($scope, $http, listService, $timeout, resourceFactory ,$stateParams){
	$scope.newBook = {};
	$scope.SubmitForm = function(){
		resourceFactory.post(this.newBook, function(r){
			$scope.response = r.code;
			if( $scope.response == 200){
				$scope.successFlag = true;
				
			}else {
				$scope.successFlag = false;
				
			}
			console.log($scope.successFlag);
		})
		
	};
});
Capstone.factory('resourceFactory', function($resource) {
  return $resource('/product/:id',{}, {
  query: {method:'GET', params:{id: '@id'}},
  post: {method:'POST'},
  update: {method:'PUT', params: {id: '@id'}},
  remove: {method:'DELETE'}
});
});
Capstone.factory("listService", function($http){
	var listService = {
    async: function() {
      var promise = $http.get('/products')
      	.then(function (response) {
           return response.data;
      });
      return promise;
    }
  };
  return listService;
});

Capstone.config(function($stateProvider, $urlRouterProvider){
	$urlRouterProvider.otherwise('/');
	$stateProvider
	.state("home", {
		url: "/",
		templateUrl : "/pages/list.html",
		controller: "listCtrl"
	}).state("create",{
		url: "/create",
		
			templateUrl : "/pages/book.html",
		controller: "addNewCtrl"
	}).state("edit:id", {
		url: "/edit/:id",
		
			templateUrl : "/pages/book.html",
		controller : "editCtrl"
	});
});
